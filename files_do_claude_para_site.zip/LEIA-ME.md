# Como colocar o site no ar (grátis) — passo a passo

## 1. Publicar o site gratuitamente (GitHub Pages)

1. Crie uma conta em https://github.com (grátis)
2. Crie um novo repositório público, ex: `achados-praticos`
3. Envie estes 4 arquivos para o repositório: `index.html`, `style.css`, `organizar-apartamento-pequeno.html`, `presentes-praticos.html`
4. Vá em **Settings → Pages** do repositório → em "Source" escolha a branch `main` → Save
5. Em alguns minutos seu site estará no ar em algo como `https://seunome.github.io/achados-praticos`

Alternativa mais simples (sem mexer com GitHub): criar o site direto no **Blogger.com** (Google) ou **WordPress.com** no plano grátis, colando o conteúdo dos artigos manualmente.

## 2. Colocar os links de afiliado de verdade

Os botões "Ver produto →" nos artigos estão com `href="#"` (não levam a lugar nenhum ainda). Você precisa:

1. Criar conta em um programa de afiliados:
   - **Amazon Associados** (associados.amazon.com.br) — o mais fácil de aprovar
   - **Mercado Livre Afiliados** (mercadolivre.com.br/afiliados)
   - **Magalu Parceiro** (parceiro.magazineluiza.com.br)
2. Escolher um produto real parecido com o descrito no artigo
3. Gerar o link de afiliado daquele produto
4. Abrir o arquivo `.html` do artigo e trocar `href="#"` pelo link de afiliado gerado

**Importante:** troque também o texto genérico de cada produto pelo nome real do produto escolhido (título, marca, preço aproximado) — isso ajuda a converter mais.

## 3. Adicionar mais produtos/artigos (fazer o site crescer)

Cada artigo já tem no fim um aviso `[Espaço reservado...]`. Para adicionar mais um item, copie e cole este bloco antes desse aviso, ajustando o número e o texto:

```html
<h2>Título curto do que esse produto resolve</h2>
<div class="product">
  <span class="rank">Nº 4</span>
  <h3>Nome do produto</h3>
  <p>Por que esse produto ajuda / o que ele resolve.</p>
  <a class="btn" href="LINK_DE_AFILIADO_AQUI" target="_blank" rel="nofollow sponsored">Ver produto →</a>
</div>
```

Para criar um artigo novo do zero, duplique um dos arquivos `.html` existentes, troque título, texto e produtos, e adicione um novo bloco `<a class="entry">...</a>` no `index.html` apontando pro novo arquivo.

## 4. Depois de publicado — o que realmente importa

- **Google Search Console** (search.google.com/search-console, grátis): cadastre seu site pra ele aparecer nas buscas do Google. Sem isso, praticamente ninguém te encontra.
- **Tempo pra resultado:** sites novos levam entre 2 e 6 meses pra começar a aparecer no Google e gerar tráfego/vendas. Não é falha do site — é assim que funciona.
- **O que mais importa pra crescer:** publicar mais artigos (mesmo curtos) com regularidade conta mais do que deixar 2 artigos "perfeitos" parados.
- **Divulgação inicial:** compartilhar os artigos em grupos de Facebook/WhatsApp relacionados ao tema (organização, decoração) pode trazer as primeiras visitas antes do Google indexar.

## 5. Ideias de próximos artigos (mesmo nicho)

- Produtos para organizar cozinha pequena
- Itens para quem trabalha em home office
- Achados para banheiro pequeno
- Presentes de até R$50 que realmente são usados
